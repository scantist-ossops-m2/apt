#ifndef APT_PRIVATE_LIST_H
#define APT_PRIVATE_LIST_H

#include <apt-pkg/cmndline.h>

bool List(CommandLine &Cmd);


#endif
