#ifndef APT_PRIVATE_UTILS_H
#define APT_PRIVATE_UTILS_H

#include<string>

void DisplayFileInPager(std::string filename);
void EditFileInSensibleEditor(std::string filename);



#endif
