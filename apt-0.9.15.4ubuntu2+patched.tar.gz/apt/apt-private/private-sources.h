#include <apt-pkg/cmndline.h>

bool EditSources(CommandLine &CmdL);
