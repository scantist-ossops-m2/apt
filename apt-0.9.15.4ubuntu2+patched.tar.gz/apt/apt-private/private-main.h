#ifndef APT_PRIVATE_MAIN_H
#define APT_PRIVATE_MAIN_H

#include <apt-pkg/cmndline.h>

void CheckSimulateMode(CommandLine &CmdL);


#endif
