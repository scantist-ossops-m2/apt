#ifndef APT_PRIVATE_UPDATE_H
#define APT_PRIVATE_UPDATE_H

class CommandLine;

bool DoUpdate(CommandLine &CmdL);

#endif
