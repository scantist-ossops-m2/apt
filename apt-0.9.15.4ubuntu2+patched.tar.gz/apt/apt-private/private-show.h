#ifndef APT_PRIVATE_SHOW_H
#define APT_PRIVATE_SHOW_H

#include <apt-pkg/cmndline.h>

namespace APT {
   namespace Cmd {

      bool ShowPackage(CommandLine &CmdL);
   }
}
#endif
