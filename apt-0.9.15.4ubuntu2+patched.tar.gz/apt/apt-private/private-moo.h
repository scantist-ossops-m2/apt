#ifndef APT_PRIVATE_MOO_H
#define APT_PRIVATE_MOO_H

class CommandLine;

bool DoMoo(CommandLine &CmdL);
bool DoMoo1(CommandLine &CmdL);
bool DoMoo2(CommandLine &CmdL);
bool DoMoo3(CommandLine &CmdL);
bool DoMooApril(CommandLine &CmdL);

#endif
