#ifndef APT_PRIVATE_SEARCH_H
#define APT_PRIVATE_SEARCH_H

#include <apt-pkg/cmndline.h>

bool FullTextSearch(CommandLine &CmdL);


#endif
