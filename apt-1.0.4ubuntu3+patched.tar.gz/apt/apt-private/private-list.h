#ifndef APT_PRIVATE_LIST_H
#define APT_PRIVATE_LIST_H

#include <apt-pkg/macros.h>

class CommandLine;

APT_PUBLIC bool DoList(CommandLine &Cmd);


#endif
